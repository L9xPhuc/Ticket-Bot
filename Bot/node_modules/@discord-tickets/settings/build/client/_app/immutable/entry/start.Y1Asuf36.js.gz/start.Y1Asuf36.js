import{a as t}from"../chunks/DYdhc7Mi.js";export{t as start};
