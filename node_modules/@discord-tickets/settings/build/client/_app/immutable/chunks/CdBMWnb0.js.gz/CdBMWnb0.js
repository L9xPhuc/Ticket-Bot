import{l as r,F as c,i,E as s,j as h,G as m,m as p}from"./D0Xv9YzD.js";function l(t,f,o){r&&c();var n=t,a,e;i(()=>{a!==(a=f())&&(e&&(m(e),e=null),a&&(e=h(()=>o(n,a))))},s),r&&(n=p)}export{l as c};
