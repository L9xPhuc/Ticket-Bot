import{a as t}from"./y_msc5TT.js";const a=t({questions:[]}),o=t({tags:[]});export{a as q,o as t};
