import{i,E as o,j as f,n as p,k as c,l as d,m as h}from"./D0Xv9YzD.js";function E(s,e,...t){var r=s,n=p,a;i(()=>{n!==(n=e())&&(a&&(c(a),a=null),a=f(()=>n(r,...t)))},o),d&&(r=h)}export{E as s};
